<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog - Blog</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <div class="logo">
            <a href="index.php"><img src="https://devriazul.fastitbd.com/images/riazul.png" alt="Logo" class="logo" width="50px"></a>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li class="active"><a href="blog.php">Blog</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <main>

        <div class="">
            <section class="featured">

                <h1>Blog</h1>

                <div class="post">
                    <img src="https://img.freepik.com/free-photo/online-message-blog-chat-communication-envelop-graphic-icon-concept_53876-139717.jpg" alt="Post Image">
                    <h2>Post Title</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum, justo eget ornare sagittis, velit velit bibendum tortor, vel luctus velit lectus sit amet mauris. </p>
                    <a href="post.php" class="read-more">Read More</a>
                </div>

                <div class="post">
                    <img src="https://img.freepik.com/free-photo/online-message-blog-chat-communication-envelop-graphic-icon-concept_53876-139717.jpg" alt="Post Image">
                    <h2>Post Title</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum, justo eget ornare sagittis, velit velit bibendum tortor, vel luctus velit lectus sit amet mauris. </p>
                    <a href="post.php" class="read-more">Read More</a>
                </div>

                <div class="post">
                    <img src="https://img.freepik.com/free-photo/online-message-blog-chat-communication-envelop-graphic-icon-concept_53876-139717.jpg" alt="Post Image">
                    <h2>Post Title</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum, justo eget ornare sagittis, velit velit bibendum tortor, vel luctus velit lectus sit amet mauris. </p>
                    <a href="post.php" class="read-more">Read More</a>
                </div>

            </section>

            <aside class="sidebar">

                <div class="widget">
                    <h3>Search</h3>
                    <form>
                        <input type="text" placeholder="Search...">
                        <button type="submit">Go</button>
                    </form>
                </div>

                <div class="widget">
                    <h3>Categories</h3>
                    <ul>
                        <li><a href="#">Category 1</a></li>
                        <li><a href="#">Category 2</a></li>
                        <li><a href="#">Category 3</a></li>
                        <li><a href="#">Category 4</a></li>
                    </ul>
                </div>

            </aside>
        </div>

    </main>

    <footer>
        <div class="container">
            <p>&copy; 2023 My Blog</p>
        </div>
    </footer>
</body>

</html>