<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <div class="logo">
            <a href="index.php"><img src="https://devriazul.fastitbd.com/images/riazul.png" alt="Logo" class="logo" width="50px"></a>
        </div>
        <nav>
            <ul>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section class="featured">
        <div class="container">
            <h1>Latest Post</h1>
            <div class="post">
                <img src="https://img.freepik.com/free-photo/online-message-blog-chat-communication-envelop-graphic-icon-concept_53876-139717.jpg" alt="Post Image">
                <h2>Post Title</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum, justo eget ornare sagittis, velit velit bibendum tortor, vel luctus velit lectus sit amet mauris. </p>
                <a href="post.php" class="read-more">Read More</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 My Blog</p>
        </div>
    </footer>

</body>

</html>