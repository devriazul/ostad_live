<?php
    include "inc/header.php";
?>

    <!-- Main Content Section -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1>About Us</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consequat ex nec mauris finibus, vel commodo nunc molestie. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc condimentum
                        justo a fermentum lobortis. Ut non nunc auctor, elementum felis sed, tristique libero. Donec venenatis est nec odio blandit luctus. Duis in augue dolor. In lobortis, sapien eget bibendum suscipit, augue quam lacinia purus, at accumsan
                        nisl enim ut sem. Aliquam erat volutpat. Etiam blandit enim eu nunc tincidunt aliquam. Integer vitae urna quis purus tincidunt laoreet sit amet ut magna. Sed scelerisque, odio id ultrices malesuada, arcu mi ultrices ex, auctor
                        venenatis metus enim vitae dolor. Praesent eu aliquam nibh.</p>
                    <p>Nulla facilisi. In malesuada tempus ipsum, ut scelerisque libero faucibus in. Sed ac justo vel odio feugiat sodales. Vestibulum porta ullamcorper urna quis lacinia. Aenean vel mollis nibh. Phasellus id ante eget ante ullamcorper lacinia
                        quis vitae elit. Pellentes ue sit amet elit eget elit dapibus pellentesque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas accumsan quam a nunc aliquam, sed bibendum nulla elementum.
                        Ut vel elit sit amet nibh suscipit sodales. Sed vel lorem a enim iaculis consectetur ut vel est.</p>
                </div>
                <div class="col-md-6">
                    <img src="https://picsum.photos/500/500" alt="About Us" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </section>
    <!-- Footer Section -->
    <?php
    include "inc/footer.php"
?>
</body>

</html>